"""Environments specified in NFQ paper."""
# flake8: noqa
from .cartpole import CartPoleRegulatorEnv
from .lunarlander import LunarLanderSetUp
