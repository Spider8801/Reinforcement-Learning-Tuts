1. Install the dependencies in an virtual environment using the requirement.txt file
2. Run the One VAL ALgorithm using the LunarLander.py file
3. Run the Neurofitte dQ iteraton algorithm using 
    Go to the implementations-nfq folder

    python train_eval_LL.py -c configuration.conf

